# Atualização visual — FMABC Eventos

## O que muda
- Substitui a letra provisória do logotipo pelo logo FMABC fornecido em CorelDRAW, exportado para PNG com fundo transparente.
- Aplica verde institucional em elementos de navegação e ações principais.
- Mantém os três cartões de eventos em destaque no azul escuro aprovado anteriormente.
- Não altera o banco de dados nem as rotas da aplicação.

## Instalação
1. Faça backup da pasta do projeto.
2. Pare o servidor local.
3. Copie `templates/base.html` e `templates/dashboard.html` para a pasta `templates` do projeto.
4. Copie `static/app.css` e `static/logo-fmabc.png` para `static`.
5. Reinicie o sistema e atualize o navegador com Ctrl+F5.

Preserve o banco de dados e o arquivo `.env`.
