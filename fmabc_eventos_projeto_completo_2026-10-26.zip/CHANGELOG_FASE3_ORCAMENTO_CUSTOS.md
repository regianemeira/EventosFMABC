# Fase 3 — Orçamento e custos

- Adicionados valores contratados e campos de acompanhamento da aprovação.
- Adicionada tabela de cotações por item de orçamento.
- Atualizada tela de orçamento com inclusão, seleção e remoção de cotações.
- Adicionado resumo por categoria.
- Adicionado relatório comparativo histórico por ano e tipo de evento.
- Mantidos os campos anteriores de orçamento previsto e realizado.
- Incluída migração SQLite aditiva para instalações existentes.
