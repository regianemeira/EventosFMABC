# Teste manual — tarefas por departamento

1. Abra **Agenda e comunicação** e selecione um mês com evento aprovado ou em planejamento.
2. Selecione a área (por exemplo, TI) para configurar as providências.
3. Abra o cartão do evento, defina **Ação necessária**, preencha a providência, responsável da área e prazo; salve.
4. Confirme que o cartão exibe status, recebimento, responsável e prazo, e que existe um link individual de acompanhamento.
5. Gere a prévia mensal da área e confira se a mensagem contém o responsável, o prazo e o link de acompanhamento (se `APP_BASE_URL` estiver configurado).
6. Abra o link individual numa nova janela e confirme o recebimento. Registre resposta “Recebemos e estamos avaliando” com status “Não iniciada”; salve.
7. Volte ao painel e confira que o recebimento e o status foram atualizados, e que o histórico registra a mudança.
8. Atualize novamente a resposta com status “Bloqueada”. Tente salvar sem justificativa — o formulário deve exigir uma. Informe a justificativa e salve.
9. Volte ao painel e confira a justificativa e o histórico.
10. Marque a providência como concluída e confirme que o painel reflete o status final.

Não realize o teste com eventos reais sem antes confirmar a configuração do e-mail e o escopo público dos links.
