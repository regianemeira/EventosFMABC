# Alterações — Gestão de tarefas por departamento

- Campo separado para confirmação de recebimento da solicitação.
- Registro do nome de quem respondeu e do responsável da área pela execução.
- Prazo da providência configurável pelo Setor de Eventos.
- Status operacional independente da resposta de atendimento.
- Justificativa obrigatória para bloqueios, espera de terceiros, alinhamento ou recusa.
- Histórico com data/hora, autor/origem e resumo das alterações.
- Links de acompanhamento individual adicionados às providências de ação necessária.
- Agenda institucional ampliada para mostrar tarefas abertas, prazos e justificativas.
- Relatórios e dados existentes são preservados pela migração aditiva do SQLite.
