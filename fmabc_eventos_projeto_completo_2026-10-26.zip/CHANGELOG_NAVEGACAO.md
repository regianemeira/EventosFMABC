FASE — SIMPLIFICAÇÃO DA NAVEGAÇÃO
- Removida do menu lateral a entrada “Triagem e acompanhamento”.
- A listagem “Solicitações e eventos” passa a indicar como ativa a navegação quando rotas de triagem ainda forem usadas.
- Perfil Equipe (staff) passa a abrir “Solicitações e eventos” após login.
- Rotas de triagem mantidas para preservar fluxos existentes.
- Nenhuma alteração no banco de dados.
